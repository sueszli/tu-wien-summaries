Stub
---
Zum Testen

Zum Verwenden, ausführbare Implementierung

Liefert vordefinierte Werte, indem Pfad vorbestimmt wird.

Erlaubt Testen von Pfaden die von außen nicht beeinflusst und durchlaufen werden können.
---
Beispiel: Asynchrone Abfrage an einem Server

orignal:
![image.png](@media/qgVKrcXQ.png)

stub:
![image.png](@media/JldyxbT4.png)
![image.png](@media/1LSFPh8O.png)