Dummy Object
---
Nicht zum Testen

Nicht zum Verwenden, nicht ausführbar

---

Quasi “leeres” Argument - Platzhalter ohne Funktionalität

zB `DummyCustomer` Klasse implementiert `ICustomer` aber wirft `NotImplementedException`