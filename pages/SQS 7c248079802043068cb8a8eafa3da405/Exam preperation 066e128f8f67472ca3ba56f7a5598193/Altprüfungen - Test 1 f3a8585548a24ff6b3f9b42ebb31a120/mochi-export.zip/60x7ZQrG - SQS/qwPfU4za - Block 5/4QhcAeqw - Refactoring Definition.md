Refactoring: Definition
---
Code Struktur ändern für bessere: Lesbarkeit, Verständlichkeit, interne Architektur/Design

Funktionalität, Fehler bleiben gleich

Ziel ist es nicht die Performance zu verbessern

---

Klare Struktur durch Kapselung, Lesbarkeit:

- Leichtere Einarbeitung von neuen Entwicklern

- Bessere Wartbarkeit, Anpassbarkeit, Erweiterbarkeit

- Geringerer Aufwand beim Testen, Leichtere Identifikation von Fehlern