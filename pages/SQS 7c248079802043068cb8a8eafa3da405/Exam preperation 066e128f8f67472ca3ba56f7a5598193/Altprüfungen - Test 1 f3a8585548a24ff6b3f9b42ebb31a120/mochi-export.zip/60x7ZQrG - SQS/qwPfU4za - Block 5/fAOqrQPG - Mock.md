Mock
---
Gleich wie Stub, aber die Argumente die an Mock gegeben werden, werden auch im Test überprüft.

Mock erkennt wenn unerwartete Werte erhalten werden - Assertion und Exception.

---

Fortsetzung Beispiel: Asynchrone Abfrage an einem Server

 Mock - Version 1: Ohne Assertions
![image.png](@media/JFSzZBov.png)

 Mock - Version 2: Mit Assertions
![image.png](@media/w3eEdadM.png)