Test doubles: Definition
---
*= Generischer Begriff für Austausch von realen Komponente des Systems durch eine alternative, meist simplifizierte Implementierung für Testzwecke.*

Wir möchten Abhängigkeiten zwischen Komponenten ausblenden.

Komponenten mit einfacheren “doubles” ersetzen zum Testen.

Vorteile: Isolation, Keine Abhängigkeiten, geringere Komplexität, Ausführungszeit, Deterministisch