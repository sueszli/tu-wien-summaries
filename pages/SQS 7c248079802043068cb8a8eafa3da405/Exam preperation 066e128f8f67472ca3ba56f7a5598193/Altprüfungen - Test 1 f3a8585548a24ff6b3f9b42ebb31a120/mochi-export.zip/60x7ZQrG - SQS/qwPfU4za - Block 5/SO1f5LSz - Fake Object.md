Fake Object
---
Nicht zum Testen

Zum Verwenden, ausführbare Implementierung

---

Wenn reale Implementierung zu langsam oder nicht verfügbar

zB simulierte Datenquelle, In-Memory Datenbank → keien Echtdaten