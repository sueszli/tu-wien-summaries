Refactoring: Bad smells
---

Kennzeichen von schlechten Designs - zeigen wo Refactoring notwendig ist.
---

Beispiele (nach Martin Fowler):

- Duplicated Code
- Long Method
- Large Class
- Long Parameter List
- Shotgut Surgery: Kleine Änderungen am Code führen zu Anpassungen in vielen Klassen
- Feature Envy: Eine andere Klasse hat mehr Nutzen für eine Funktion
- …