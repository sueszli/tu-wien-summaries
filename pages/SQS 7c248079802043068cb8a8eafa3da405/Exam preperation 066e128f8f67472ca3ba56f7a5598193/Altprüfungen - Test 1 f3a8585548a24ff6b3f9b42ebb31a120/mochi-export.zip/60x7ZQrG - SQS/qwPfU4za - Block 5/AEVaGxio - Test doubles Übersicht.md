Test doubles: Übersicht
---
1. Dummy
2. Fake
3. Stub
4. Mock