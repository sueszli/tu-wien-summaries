Fehlermuster in statischer code Analyse, Einteilung der Regeln
---
Häufige Fehlermuster im Code:

- Variablen mit undefiniertem Wert
- Komplexe Konstrukte
- Toter Code
- Potenzielle Endlosschleifen
- Security Schwachstellen
- Unused Code
- …

Regeln eingeteilt in:

- Bug = Potenzielle Fehler
- Vulnerability = Sicherheitslücken
- Code Smell = Unschöner/unwartbarer Code