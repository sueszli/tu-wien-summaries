Refactoring: Technische Schuld, Bad smells
---
“Technische Schuld”: Design vernachlässigt um kurz effizienter zu sein $\rarr$ Design “verwahrlost” mit der Zeit.

*Bad Smells* zeigen das Refactoring notwendig ist.