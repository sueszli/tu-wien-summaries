Test doubles: Zweck, Motivation
---
Man kann sie nicht leicht isoliert vom restlichen System Testen weil:
- Schlechte performance
- Dependencies
  Weil sie miteinander interagieren, andere Schnittstellen aufrufen - zB Datenbank

- Nicht Determinismus
  Werte nutzen wie zB Systemzeit