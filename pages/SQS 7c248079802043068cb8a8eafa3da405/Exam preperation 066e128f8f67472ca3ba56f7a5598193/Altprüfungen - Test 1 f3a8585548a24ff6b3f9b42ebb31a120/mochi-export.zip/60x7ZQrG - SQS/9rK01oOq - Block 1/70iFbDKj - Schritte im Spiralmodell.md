Schritte im Spiralmodell
---
Orientiert an Investitionen, Risikomanagement

Jede Phase ist ein Subprojekt

1. Kickoff
  Bestimmung von Zielen und Alternativen
2. Risikoeinschätzung
  bzw Suche nach Alternativen
3. Entwicklung und Test
4. Plan von nächsten Phase

$\circlearrowleft$