Typen von Messungen / Metriken mit Beispielen

---

<span style="color:gray">*DIN 1319: “Ermitteln eines Wertes durch quantitativen Vergleich der Messgröße mit einer Einheit (Normal)”*</span>

Direkt vs. Indirekt

- Werteermittlung direkt beim Objekt (zB Dauer, Aufwand)
- Indirekt (durch Index: zB Effizienz der Fehlererkennungsmethode = Fehleranzahl / Zeit)

Objektiv vs. Subjektiv
- Subjektiv (Fragebögen für Zufriedenheit, ...)
- Objektiv (LoC, Aufwand, Deadline, ...)

Quantiativ vs. Qualitativ

- konkrete Zahlen (von statistischen Auswertungen)
- visualisierte Informationen (Text, Bilder) durch Interviews, Interpretationen, ...

---

Beispiel: Messung von
<table>
  <tr>
    <td>Prozess</td>
    <td>durch Aufwand für eine Aufgabe in PM</td>
  </tr>
  <tr>
    <td>Produkt</td>
    <td>durch Größe in Lines of Code LoCs</td>
  </tr>
  <tr>
    <td>Ressourcen</td>
    <td>durch Erfahrung in Anzahl der Projekte</td>
  </tr>
</table>