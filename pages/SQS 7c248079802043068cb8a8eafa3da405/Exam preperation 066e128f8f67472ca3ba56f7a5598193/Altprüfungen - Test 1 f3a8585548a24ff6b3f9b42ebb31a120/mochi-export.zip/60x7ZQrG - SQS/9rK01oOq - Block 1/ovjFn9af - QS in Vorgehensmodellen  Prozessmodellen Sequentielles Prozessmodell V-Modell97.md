QS in Vorgehensmodellen / Prozessmodellen: Sequentielles Prozessmodell, V-Modell97
---
Spezifikation, Voraussetzungen und Annahmen verstehen → Umsetzung, Testen

Verschiedene Sichten und Rollen

Problem: Fehler aus frühen Entwicklungsphasen übertragen sich auf die nächsten

Einsatz von QS: 
- Analytische Seite: Testplanerstellung in jeder Phase, danach immer ein Review

- Synthetische Seite: nach jeder Ebene die Tests nach Testplan durchführen (Modultests, Integrationstests, Systemtest)

![image.png](@media/kWSitLGU.png)