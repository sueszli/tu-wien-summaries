QM Definition

---

= Menge aller Aktivitäten, Vorgehensweisen, Techniken, Hilfsmittel zum Herstellen, Sicherstellen dass ein Qualitäts-Standard für das Endprodukt erreicht wird.

- Qualitäts-Planung
- Qualitäts-Lenkung
- Qualitäts-Sicherung
- Qualitäts-Verbesserung