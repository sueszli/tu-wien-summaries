Welche Möglichkeiten gibt es Software-Qualität sicher zu stellen? (QS Qualitätsmaßnahmen / Methoden)
    

---

**Konstruktive Qualitätsmaßnahmen / Methoden**

*Entwicklungsart der Produkte*

1. Technische
    Prinzipien, Methoden, Werkzeuge der SE: Model-Driven-Development, TDD
    

2. Organisatorische    
    *Schaffen Infrastruktur, steuern Qualitätsprozess*,  
    Vorgehensmodelle/Standards/Prozesse, Templates/Checklisten, Wissensmanagement
    

3. Menschliche
    Schulung von Mitarbeitern
    
<br/>
**Analytische Qualitätsmaßnahmen / Methoden**

*Prüfung und Bewertung von Produktqualität*

*Verifikation und Validierung der Projektergebnisse*


1. Statische Prüfungen    
   *Software muss nicht ausführbar oder integriert sein → Fokus auf interne Struktur*.
    Reviews, Inspektionen, Audits, toolgestützte Code Analyse
    

2. Dynamische Prüfungen    
    *Teile von Software müssen ausführbar sein*.    
    Software Tests.