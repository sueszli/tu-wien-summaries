Ziel von Softwareentwicklung und wie es erreicht werden kann
---
Ziel der SE ist es qualitativ hochwertige und testbare Software zu erstellen.

Das braucht:

- Softwareprozess (zB life-cycle Modell)
- Vorgehensmodelle (zB V-Modell XT, RUP, Spiralmodell, SCRUM)
    <span style="color:gray">Wann müssen welche Produkte in welchem Fertigstellungsgrad und auf welchem Qualitätsniveau vorliegen?</span>
- QS Methoden für Produkterstellung, Prozessverbesserung (zB Review, Inspektion, Test, PDCA-Zyklus)

Qualität dadurch nicht garantiert sondern wahrscheinlicher.