Qualitätsfaktoren nach McCall
---
<table>
  <tr>
    <td>Qualitäts-Faktoren</td>
    <td>Verhalten des Systems</td>
  </tr>
  <tr>
    <td>Qualitäts-Kriterien</td>
    <td>Bedinungen für Umsetzung in Softwareentwicklung</td>
  </tr>
  <tr>
    <td>Qualitäts-Metriken</td>
    <td>Zur Bemessung</td>
  </tr>
</table>


![Untitled (5).png](@media/rWhSKexc.png)