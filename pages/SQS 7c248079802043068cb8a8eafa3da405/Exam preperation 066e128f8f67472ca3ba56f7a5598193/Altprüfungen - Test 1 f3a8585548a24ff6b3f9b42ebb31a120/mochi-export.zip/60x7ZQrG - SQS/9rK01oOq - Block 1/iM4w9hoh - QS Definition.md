QS Definition
---
= Verifikation und Validierung in allen Phasen der Entwicklung 

durch Verfahren, Aktivitäten, Prozesse die sicherstellen, dass Produkt Anforderungen (Spezifikation und Kundenanforderungen) entspricht.
<br/>
sollte projektunabhängig organisiert sein

Qualität kann nicht später hinzugefügt werden - sie muss während der Entwicklung gesichert werden