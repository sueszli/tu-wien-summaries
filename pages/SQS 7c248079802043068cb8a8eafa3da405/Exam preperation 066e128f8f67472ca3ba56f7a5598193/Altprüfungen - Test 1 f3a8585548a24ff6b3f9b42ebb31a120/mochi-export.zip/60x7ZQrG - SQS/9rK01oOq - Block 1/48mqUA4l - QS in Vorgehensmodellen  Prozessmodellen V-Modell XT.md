QS in Vorgehensmodellen / Prozessmodellen: V-Modell XT
---

QS als <span style="color:green">eigenständiger Vorgehensbaustein</span>, verpflichtend in allen Projekttypen.

Projekttyp “Einführung und Wartung eines organisationsspezifischen Vorgehensmodells“ <span style="color:green">beinhaltet Idee der ständigen Verbesserung</span>.

Hat <span style="color:green">“Quality Gates”</span> wie zB Projektgenehmigung bei denen Qualität 
passen muss.

Qualitätsplanung, Reviews, Testen
---

![image.png](@media/TYAyZ3TQ.png)