Software-Qualität

---
<span style="color:gray">Nach DIN8402: *“Die Beschaffenheit einer Einheit bezüglich ihrer Eignung festgelegte und vorausgesetzte Erfordernisse zu erfüllen”*</span>

keine einheitliche Definition in Literatur:
Erfüllung von Anforderungen, Attributen, Qualitätsfaktoren (nach McCall),  Vorgaben, Richtlinien, Normen, Standards, gesetzlichen Regelungen (für Produkt und Dienstleistung) ...
... durch Eigenschaften, Merkmalen von Produkt, Leistung.

- im Rahmen des Budgets (alle Ressourcen wie Zeit, Geld, ...)
- für Anwender verwendbar
- für Entwickler verständlich, änderbar
- für Betreiber effizient und administrierbar
- für Kunden zufriedenstellend