QS in Vorgehensmodellen / Prozessmodellen: Rational Unified Process RUP
---
QS mit Rollen durch gesamtes Projekt → Review bei Meilensteinen

eigene “Test Discipline”