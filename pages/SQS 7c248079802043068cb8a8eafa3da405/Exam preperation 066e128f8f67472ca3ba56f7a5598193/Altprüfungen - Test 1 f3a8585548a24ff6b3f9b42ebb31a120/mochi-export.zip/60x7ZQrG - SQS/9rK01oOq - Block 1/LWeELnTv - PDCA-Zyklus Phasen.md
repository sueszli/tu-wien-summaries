PDCA-Zyklus: Phasen

---

Dient der Produktverbesserung, Prozessverbesserung

PDCA-Zyklus → Software Process Improvement SPI

- Plan
Planen: Planen der nächsten Iteration im SPI-Zyklus mit Erfahrungswerten, Zielsetzung

- Do
Implementierung: Aktivität (Task, Projekt) durchführen

- Check
Analytische QS: Überprüfung der Ergebnisse (Produkt, Prozess) durch Messung

- Act
Rückkopplung nach Ergebnissanalyse: Erkenntnisse im nächsten Zyklus nutzen

*wiederholen $\circlearrowleft$*