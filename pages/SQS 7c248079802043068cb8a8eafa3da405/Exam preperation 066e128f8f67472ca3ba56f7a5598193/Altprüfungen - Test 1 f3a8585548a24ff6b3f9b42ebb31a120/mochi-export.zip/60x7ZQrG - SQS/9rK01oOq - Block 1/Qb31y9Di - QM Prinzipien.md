QM Prinzipien

---

Prinzip der ständigen Bewertung, Verbesserung von Produkten, Prozessen, eingesetzten Qualitätsmaßnahmen

Organisation nach QM-Systemen (z.B. ISO 9001, CMM-I, SPICE-ISO 15504)

Feedback um in jeder Phase (Entwicklung, Test, Betrieb, Wartung)

- frühzeitige Entdeckung, Behebung von Fehler und Mangel
- konkrete, operationalisierbare Qualitätsmerkmale
- produktunabhängige, projektunabhängige Qualitätsplanung
- unabhängige, mehraugenkontrollierte, rückgekoppelte (Fehler beheben) Qualitätsprüfungen