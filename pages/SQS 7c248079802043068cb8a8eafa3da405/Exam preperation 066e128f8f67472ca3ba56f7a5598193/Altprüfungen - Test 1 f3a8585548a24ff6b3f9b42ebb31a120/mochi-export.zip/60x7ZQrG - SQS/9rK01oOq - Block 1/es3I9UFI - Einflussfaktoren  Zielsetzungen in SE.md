Einflussfaktoren / Zielsetzungen in SE

---

Beeinflussen sich gegenseitig:
<table>
  <tr>
    <td>Qualität</td>
    <td>Fehleranzahl, Termintreue, Kostentreue</td>
  </tr>
  <tr>
    <td>Quantität</td>
    <td>Umfang: Anzahl der implementierten Funktionen, LoC</td>
  </tr>
  <tr>
    <td>Entwicklungsdauer</td>
    <td>Aufwand: zB in (Personen-)Monaten</td>
  </tr>
  <tr>
    <td>Kosten</td>
    <td>Ausgaben</td>
  </tr>
</table>


Teufelsquadrat nach Sneed:
Spannungsfeld - Fläche des Quadrates (= Produktivität) ändert sich nicht

zB Mehr Qualität, kürzere Entwicklungsdauer = Geringerer Umfang, Erhöhung von Kosten

![image.png](@media/pOJ6AzYN.png)