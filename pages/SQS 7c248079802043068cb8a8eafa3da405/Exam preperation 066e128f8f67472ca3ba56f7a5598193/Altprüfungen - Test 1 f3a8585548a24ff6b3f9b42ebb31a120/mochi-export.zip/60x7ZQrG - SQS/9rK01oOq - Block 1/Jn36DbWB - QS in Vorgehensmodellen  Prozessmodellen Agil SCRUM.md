QS in Vorgehensmodellen / Prozessmodellen: Agil (SCRUM)

---

Reviews nach jedem Sprint

Test Driven Development TDD