Qualitäts-Maßnahmen die besonders zu unterstützen sind
---
Maßnahmen die

- Hygienefaktoren betreffen
    Hygienefaktoren werden von Entwicklern leicht ausgeblendet → schnelles Feedback an Entwickler in unterschiedlichen Phasen (direkt und indirekt)
    

- vorbeugend wirken - die "Das richtige machen" möglichst einfach machen und "Das falsche machen" möglichst schwer machen.