Qualitätsfaktoren: Mehrwert vs. Hygienefaktor
---
– Kunde zahlt Aufpreis für Mehrwert
– Kunde nimmt Produkt (egal wie gut es ist) Hygienefaktor-Mängeln nicht an