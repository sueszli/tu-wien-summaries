Leistungen von QS Stelle
---
- Qualitätsplanung in Projektplanung
- Lokale Standards auf Projektebene, Organisationsebene einhalten
- Organisation und Durchführung von QS-Maßnahmen:
  - zB für Review: Organisation, Ausbildung, Planung, Durchführung, Verbesserungsvorschläge
  - zB für Produkt-Tests: Vorbereitung, Auswertung
- Unterstützung bei Aufnahme von Personal, Zukauf von Werkzeugen