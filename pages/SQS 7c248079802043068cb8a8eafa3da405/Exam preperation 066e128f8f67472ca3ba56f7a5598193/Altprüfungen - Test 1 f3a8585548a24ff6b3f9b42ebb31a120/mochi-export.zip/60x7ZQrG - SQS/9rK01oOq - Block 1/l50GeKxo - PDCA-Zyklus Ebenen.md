PDCA-Zyklus: Ebenen

---

Arbeitspaket-Ebene (work space level, task level)

Projekt-Ebene

Unternehmens-Ebene (management, QM-Systeme)