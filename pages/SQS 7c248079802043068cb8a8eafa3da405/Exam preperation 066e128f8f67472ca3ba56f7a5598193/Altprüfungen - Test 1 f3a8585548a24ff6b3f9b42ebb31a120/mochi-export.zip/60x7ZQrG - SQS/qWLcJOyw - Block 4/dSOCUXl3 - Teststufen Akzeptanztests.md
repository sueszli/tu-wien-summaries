Teststufen: Akzeptanztests
---
Testen ob System im produktiven Einsatz den Abnahmekriterien vom Kunden entspricht (Validierung).

Dient *nicht* dazu Fehler im System zu finden.

wie Systemtest nur von Kunde, Benutzer ausgeführt