Kontrollflussorientiertes Testen: $\small C_2$ - Bedingungsüberdeckung / Condition Coverage _(Mehrfach)_
---
Mehrfach-Bedingungsüberdeckungstest


Ziel: Überprüfung zusammengesetzter Entscheidungen und Teilentscheidungen

Test aller `true`/`false`-Kombinationen der atomaren Teilentscheidungen
    
---

**Beispiel**

Entscheidung `(((a == 0) || (b < 5)) && (x < 6) || (y == 0)))` ist äquivalent zu `((A || B) && (C || D))` wenn `a`, `b`, `x`, `y` unabhängig sind.

Dann können die Teilaussagen `A`, `B`, `C`, `D` unabhängig voneinander true oder false sein.

Dadurch $\small 2^4 = 16$  Kombinationen bzw Testfälle.
---


![image.png](@media/xIXlH4HL.png)