Teststufen, Testtypen: Übersicht
---
Teststufen sind Tests auf unterschiedlichen Ebenen des Entwicklungsprozesses.

Teststufen:
- Akzeptanztests / Abnahmetests
- Systemtests
- Integrationtests
- Komponententests / Modultests / Unittests
- <span style="color:gray">Privater Test</span>
    <span style="color:gray">Vom Entwickler vor der Freigabe, undokumentiert</span>
- <span style="color:gray">Regressionstests</span>
    <span style="color:gray">Vor Durchführung von Veränderungen - Wiederholung von Tests</span>
---
Teststufe besteht aus einem oder mehreren Test-Typen (bestimmte Art von Tests).

Testtypen:
- Review
- Funktionaler-Test
- Massentest
- Stresstest
- Performancetest