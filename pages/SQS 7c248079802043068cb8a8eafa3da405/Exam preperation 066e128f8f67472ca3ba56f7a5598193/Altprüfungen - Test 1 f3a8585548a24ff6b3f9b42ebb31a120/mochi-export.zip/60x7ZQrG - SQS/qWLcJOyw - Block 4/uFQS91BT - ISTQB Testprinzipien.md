ISTQB Testprinzipien
---
1. Testen zeigt Fehler auf
    beweist aber nicht Fehlerfreiheit.
    “Testen zeigt die Anwesenheit von Fehlern, nicht die Abwesenheit”.

    
2. Vollständiges Testen ist nicht möglich
    Nicht alle Kombinationen an Eingaben, Vorbedingungen, Zuständen testbar (praktikabel zu testen).
    Stattdessen priorisiert nach Risiko testen.

    
3. Frühzeitig Testen
    Je früher Fehler gefunden werden desto einfacher und günstiger zu beheben.

    
4. Fehlerhäufungen beachten
    Fehler sind nicht gleichmäßig verteilt - tendenziell dort wo Fehler gefunden auch mehr zu erwarten.


5. Veränderung statt Wiederholung
    Wiederholtes ausführen von den selben Testcases wird keine neuen Fehler finden.

    
6. Testen ist kontextabhängig


7. Fehlerlose Systeme sind nicht notwendigerweise brauchbar    
    Fehler finden, beheben garantiert nicht, dass Produkt den Anforderungen und Bedürfnissen vom Benutzer entspricht