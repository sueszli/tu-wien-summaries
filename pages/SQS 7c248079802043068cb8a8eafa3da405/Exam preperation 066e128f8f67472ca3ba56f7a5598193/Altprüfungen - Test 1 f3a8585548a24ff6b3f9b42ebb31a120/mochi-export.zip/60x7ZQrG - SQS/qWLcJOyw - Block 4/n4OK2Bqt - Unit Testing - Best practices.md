Unit Testing - Best practices
---
- Testfälle sind isoliert
    keine Abhängigkeiten zueinander: Jeder Testfall bereitet eigene Daten vor, räumt sie auf

    
- Keine Logik in Tests (Abfragen, Schleifen, try/catch)


- Jeder Testfall testet nur einen Aspekt bzw Zustand
    Nur ein Testfall per Methode
    Keine Zufallsdaten sondern Äquivalenzklassen

    
- Namenskonventionen einhalten


- Verständliche Fehlermeldungen bei Assertions


- Klassen und Testklassen liegen im selben Package