Kontrollflussorientiertes Testen: $\small C_1$ - Zweigüberdeckung / Branch Coverage
---

Jede Kante min 1x durchlaufen

Zeigt ob nicht ausführbare Programmzweige existieren

---

![image.png](@media/zNm3YhZt.png)