Fehlerquellen
---
Fehler in:
- Anforderungen
- Spezifikation
- Design / source-code
  - durch ungenauen, falsch interpretierten Anforderungen
  - durch Mangel an Erfahrung mit Technologie
- Fehler in Testdaten