Testentwurfsverfahren: Übersicht
---
1. Blackbox Tests (Box geschlossen lassen)
2. Whitebox Tests (in Box hineinschauen)
3. Erfahrungsbasiertes Testen / Exploratives Testen
    (zusätzlich zu anderen Testentwurfsverfahren)