Teststufen: Integrationstests
---
Testen mit dem Ziel Fehler in Interaktion zwischen Komponenten / Schnittstellen zu finden.

Zusammenführung (Integration) von mehreren Komponenten.

von Entwicklern erstellt und ausgeführt

Kann mehrere Integrationsstufen haben