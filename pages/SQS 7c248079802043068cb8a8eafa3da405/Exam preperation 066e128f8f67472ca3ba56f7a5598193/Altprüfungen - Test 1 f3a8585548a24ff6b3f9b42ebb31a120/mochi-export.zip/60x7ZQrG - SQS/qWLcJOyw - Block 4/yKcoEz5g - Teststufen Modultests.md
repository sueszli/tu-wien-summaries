Teststufen: Modultests
---
Testet Komponente isoliert vom restlichen System gegen Spezifikation.

braucht Zugang zu Source-Code

Testet Implementierung: Argumente werden übergeben, Ausgabe wird kontrolliert

von Entwicklern erstellt und ausgeführt