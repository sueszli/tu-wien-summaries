Testentwurfsverfahren: Blackbox Tests vs. Whitebox Tests
---
Blackbox Tests

- basiert auf Spezifikation ohne Wissen über innere Struktur
- Daten-getrieben (Input-Output getrieben)
- Überdeckung von Anforderungen
- Partitionierung der Eingabedaten nach Äquivalenzklassen und Grenzwerte

---

Whitebox Tests

- basiert auf Code-Struktur, Modulen mit Wissen über innere Struktur
- Logik-getrieben
- Überdeckung von Knoten, Kanten, Pfaden
- Partitionierung von Eingabedaten für Bedingungsüberdeckung ($\small C_0 - C_3$)