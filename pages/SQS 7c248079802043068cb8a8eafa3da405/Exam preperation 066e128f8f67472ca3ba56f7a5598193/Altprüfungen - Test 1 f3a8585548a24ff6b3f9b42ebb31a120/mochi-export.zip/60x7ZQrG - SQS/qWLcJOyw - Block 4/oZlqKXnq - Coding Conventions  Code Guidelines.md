Coding Conventions / Code Guidelines
---
Einheitlicher Stil im Projekt für jede Programmiersprache

bessere Lesbarkeit, Verständlichkeit

Eigene Regeln für
- Dokumentation
- Einrückung (space/tab)
- Max Zeilenlänge
- Import Reihenfolge
- Methoden/Feld Reihenfolg, Modifier/Sichtbarkeit, Veränderbarkeit
- System.out Vermeidung, Logging
- Namenskonventionen
- Code Formatierung