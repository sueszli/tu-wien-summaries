Kontrollflussorientiertes Testen: $\small C_2$ - Bedingungsüberdeckung / Condition Coverage _(Einfach)_
---

Einfacher Bedingungsüberdeckungstest

Alle atomaren Teilentscheidungen gleichzeitig `true` oder `false`
    
---

![image.png](@media/XGehxnGP.png)