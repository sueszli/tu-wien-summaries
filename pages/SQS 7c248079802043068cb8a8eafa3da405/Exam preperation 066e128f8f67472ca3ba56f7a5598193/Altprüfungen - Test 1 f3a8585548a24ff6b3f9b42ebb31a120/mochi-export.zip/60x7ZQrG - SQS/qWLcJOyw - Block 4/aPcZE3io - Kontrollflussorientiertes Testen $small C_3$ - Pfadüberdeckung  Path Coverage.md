Kontrollflussorientiertes Testen: $\small C_3$ - Pfadüberdeckung / Path Coverage
---
Abdeckung aller möglichen Pfade (Knotenfolgen)

für komplexe Module nicht geeignet (vor allem wenn Schleifen involviert sind)
---
![image.png](@media/vm5oYhoK.png)