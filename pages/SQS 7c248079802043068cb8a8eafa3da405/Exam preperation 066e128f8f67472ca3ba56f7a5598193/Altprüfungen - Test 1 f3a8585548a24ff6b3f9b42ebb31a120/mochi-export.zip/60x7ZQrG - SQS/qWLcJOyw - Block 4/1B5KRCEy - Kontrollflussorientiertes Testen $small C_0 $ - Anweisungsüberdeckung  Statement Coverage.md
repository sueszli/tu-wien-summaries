Kontrollflussorientiertes Testen: $\small C_0 $ - Anweisungsüberdeckung / Statement Coverage
---
Jede Anweisung min 1x durchlaufen

Zeigt ob toter Code existiert (falls sie nie durchlaufen werden können)

Zu schwaches Kriterium für sinnvolle Tests
---
![image.png](@media/B8F8EZNh.png)