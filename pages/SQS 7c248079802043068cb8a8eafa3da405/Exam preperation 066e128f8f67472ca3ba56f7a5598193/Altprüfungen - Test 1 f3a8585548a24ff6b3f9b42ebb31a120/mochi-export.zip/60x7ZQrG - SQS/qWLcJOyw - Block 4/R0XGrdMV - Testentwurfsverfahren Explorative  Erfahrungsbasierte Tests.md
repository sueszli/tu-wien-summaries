Testentwurfsverfahren: Explorative / Erfahrungsbasierte Tests
---
zusätzlich zu anderen Testentwurfsverfahren

basiert auf Intuition, Erfahrung des Testers $\rarr$ zB Erfahrung aus anderen Projekten, Stellen die unter Zeitdruck entstanden sind etc.

muss dokumentiert werden