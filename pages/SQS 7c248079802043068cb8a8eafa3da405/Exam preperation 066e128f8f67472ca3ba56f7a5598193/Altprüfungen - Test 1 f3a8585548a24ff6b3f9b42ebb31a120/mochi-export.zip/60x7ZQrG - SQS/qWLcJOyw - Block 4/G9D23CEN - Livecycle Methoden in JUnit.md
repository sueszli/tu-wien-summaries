Livecycle Methoden in JUnit
---
```java
class StandardTest {
	
	@BeforeAll
	static void initAll() {...}
	
	@AfterAll
	static void tearDownAll() {...}
	
	@BeforeEach
	void init() {...}
	
	@AfterEach
	void tearDown() {...}
	
	@Test
	void testAdd_shouldDoSomething() {...}
}
```

`@BeforeClass`		wird einmal bei der Initialisierung der Klasse ausgeführt.

`@AfterClass`		wird einmal vor verlassen der Klasse ausgeführt

`@Before` 			wird vor jeder Test-Methode ausgeführt

`@After`			wird nach jeder Test-Methode ausgefüht