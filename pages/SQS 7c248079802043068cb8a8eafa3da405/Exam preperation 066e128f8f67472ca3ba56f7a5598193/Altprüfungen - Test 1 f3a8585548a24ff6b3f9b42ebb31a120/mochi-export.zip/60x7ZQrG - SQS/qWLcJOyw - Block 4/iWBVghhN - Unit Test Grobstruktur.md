Unit Test Grobstruktur
---
1. Set-Up (Vorbereitung)
2. Exercise (Ausführung)
3. Verify (Auswertung)
4. Tear-Down (Nachbearbeitung / zerstören)