Kontrollflussorientiertes Testen: Definition
---
Test Abdeckung = Code Coverage (sieht man in Coverage Reports)

Kontrollflussorienterte Verfahren

- = Überdeckungstests <span style="color:green">*(für Code Coverage)*</span>
- strukturorientiert (basiert auf Kontrollfluss des Programmes)
- relevant auf Unit Test Ebene <span style="color:green">(*Whitebox Tests*)</span>
- definieren keine Regeln für Erzeugung von Testdaten