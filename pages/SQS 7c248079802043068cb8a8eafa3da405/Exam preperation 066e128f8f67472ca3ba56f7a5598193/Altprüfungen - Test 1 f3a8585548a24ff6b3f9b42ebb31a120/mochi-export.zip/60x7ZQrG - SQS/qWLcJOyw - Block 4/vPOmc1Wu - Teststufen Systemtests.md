Teststufen: Systemtests
---
Testen vom integrierten System nach Kunden-Anforderungen (Validierung) und nach Spezifikation (Verifikation).

<span style="color:gray" style="margin-left:2rem"> Basiert auf: Anforderungsspezifikation, Use-Cases, Geschäftsprozesse</span>

Testumgebung sollte Abbild der Produktivumgebung sein (keine umgebungsspezifischen Fehler).

von unabhängigem Testteam ausgeführt