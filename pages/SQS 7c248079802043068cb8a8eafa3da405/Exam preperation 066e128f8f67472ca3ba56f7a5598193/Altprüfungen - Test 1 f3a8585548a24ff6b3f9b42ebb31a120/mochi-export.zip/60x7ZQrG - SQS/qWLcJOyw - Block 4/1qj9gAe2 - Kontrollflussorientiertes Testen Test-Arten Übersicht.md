Kontrollflussorientiertes Testen: Test-Arten Übersicht
---
Man kann auch coverage von Klassen und Funktionen testen.

$C_0$  - Anweisungsüberdeckung / Statement Coverage

$C_1$ - Zweigüberdeckung / Branch Coverage

$C_2$ - Bedingungsüberdeckung / Condition Coverage

$C_3$ - Pfadüberdeckung / Path Coverage