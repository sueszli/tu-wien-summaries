Reviews für Anforderungen und erstrebenswerte Eigenschaften von Anforderungen
---
Überprüfung, Verbesserung von Anforderungs-Qualität

SRR: Software Requirement Review

- Prüfen Korrektheit von Anforderung
- Phase: Systemspezifikation

PDR: Preliminary Design Review

- Prüfen technische Angemessenheit von Design (mit aktueller Beschreibung)
- Phase: Systemdesign

---

Erstrebenswerte Beschreibung: verständlich, konsistent, vollständig, umsetzbar

Klassifikation nach Kriterien: funktional, nichtfunktional, testbar, verständlich, rückverfolgbar (zu Anforderungsdokumenten zB Projektbeschreibung) - später hergestellte Dokumente dann gegen Anforderungen