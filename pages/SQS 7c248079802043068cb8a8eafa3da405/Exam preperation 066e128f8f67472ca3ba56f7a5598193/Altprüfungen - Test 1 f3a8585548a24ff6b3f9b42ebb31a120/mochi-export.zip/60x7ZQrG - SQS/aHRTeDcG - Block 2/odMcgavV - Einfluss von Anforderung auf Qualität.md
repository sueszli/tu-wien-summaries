Einfluss von Anforderung auf Qualität
---
Anforderung $\mapsto$ Qualitätsdefinition

- Anforderungen beschreiben Funktionen und *Qualitäten*

- *Qualitäten* müssen testbar beschrieben werden