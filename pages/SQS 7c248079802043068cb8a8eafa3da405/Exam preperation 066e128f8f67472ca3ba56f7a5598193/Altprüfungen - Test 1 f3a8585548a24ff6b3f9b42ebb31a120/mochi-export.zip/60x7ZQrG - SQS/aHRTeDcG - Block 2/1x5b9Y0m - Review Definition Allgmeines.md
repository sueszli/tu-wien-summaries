Review: Definition, Allgmeines
---
Qualitative Beurteilung von Produkten, Prozessen (wo quantitative Beurteilung schwer)

Mängel entdeckt, nicht korrigiert

<span style="color:gray">IEE: “Ein Review ist ein [..] formal geplanter und strukturierter Analyse- und Bewertungsprozess, in dem Projektergebnisse einem Team von Gutachtern präsentiert und von diesen kommentiert oder genehmigt werden.“</span>

Richtlinien:
- Produkt nicht der Autor soll Reviewed werden
- Verwendung eines Arbeitsplans
- Diskussion sachlich und Kurz
- Keine Lösungen suchen, nur Fehler
- Schriftliche Aufzeichnung führen
- Anzahl der Teilnehmer begrenzen
- Teilnehmer sollen gut vorbereitet sein
- Auch Review selbst danach beurteilen