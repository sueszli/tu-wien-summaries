Lesetechniken im Vergleich
---
Ad hoc

- Unstrukturiertes Lesen
- braucht hohe Kenntnisse des Gutachters

Checklistenbasiert

- vordefinierte Fragestellungen sequentiell abarbeiten
- generische Checklisten für das Projekt erweitert:
  Checklisten für besondere Fehlertypen, Fehlerorte (Design, Code) usw
- Durch Struktur gut wiederholbar

Perspektivenbasiert

- Fehlersuche aus Perspektiven / Rollen (User, Tester, Entwickler)
- braucht Fachspezialisten

Fehlerbasiert

- Spezielle Form von checklistenbasierter Lesetechnik
- Fehler in Fehlerkategorien eingeteilt

Szenariobasiert — Usage-Based Reading (UBR)

- Best Practice
- Szenarien / Use Cases die durch Fachspezialisten priorisiert werden.
- Fehlersuche nach Priorität.
    1. Auswahl des wichtigsten Anwendungsfalles
    2. Überprüfung der relevanten Teile dafür
    3. Reporting von Mängel, Fehler
    
    $\circlearrowleft$