Reviews im V-Modell (Zugehörigkeit zu Tests)
---
<span style="color:gray">*Siehe Block 1*</span>
Einsatz von QS → Analytische Seite → Testplanerstellung in jeder Phase, danach immer ein Review