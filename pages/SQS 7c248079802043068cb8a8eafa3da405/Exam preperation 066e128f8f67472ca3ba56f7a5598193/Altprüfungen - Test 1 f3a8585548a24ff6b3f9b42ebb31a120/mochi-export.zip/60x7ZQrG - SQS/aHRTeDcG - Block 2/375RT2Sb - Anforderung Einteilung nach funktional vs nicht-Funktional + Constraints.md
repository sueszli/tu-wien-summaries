Anforderung: Einteilung nach funktional vs. nicht-Funktional + Constraints
---

**Funktionale Anforderungen**

Beschreiben was das System tut, um <span style="color:green">Mehrwert für die Stakeholder</span> zu liefern

Bilden ein <span style="color:green">Anwendungs-Szenario / Use case</span>: Meistens in der Form: “System kann Funktion X ausführen”

<span style="color:gray">Beispiele:</span>

- <span style="color:gray">Das System kann gespeicherte Rechnungen als ausdruckbare Datei exportieren.</span>
- <span style="color:gray">Der Administrator kann Bestellungen stornieren</span>

---

**Nichtfunktionale Anforderungen**
<span style="color:green"> = Qualitätsanforderungen </span>

Charakteristika, nicht-technische Beschreibung, Eigenschaften

<span style="color:gray">Beispiele:</span>
- <span style="color:gray">Wenn ein Fehler eintritt, informiert das System den Benutzer und arbeitet in einem verschlechterten(degradierten) Zustand weiter.</span>
- <span style="color:gray">Falls das System die Anzahl der Bestellungen nicht verarbeiten kann, trennt es einige bestehende Verbindungen zu Clients. Die Administratorin wird informiert und das System arbeitet in einem verschlechterten(degradierten) Zustand weiter.</span>

---

**Constraints**

Einschränkungen des Systems durch das Framework bzw. die Architektur die gewählt wurde.