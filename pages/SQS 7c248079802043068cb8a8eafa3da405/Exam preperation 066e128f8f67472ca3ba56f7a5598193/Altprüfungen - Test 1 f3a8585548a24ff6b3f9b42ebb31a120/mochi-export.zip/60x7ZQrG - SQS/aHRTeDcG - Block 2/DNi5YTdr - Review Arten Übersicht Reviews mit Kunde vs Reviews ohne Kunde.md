Review Arten Übersicht: Reviews mit Kunde vs. Reviews ohne Kunde
---
Mit Kunde

- SRR: Software Requirement Review
    <span style="color:gray">Review von Anforderungen und ihrer Verständlichkeit. Wird in der Systemspezifikationsphase verwendet.</span>
    

- PDR: Preliminary Design Review
    <span style="color:gray">Vergleich von: momentanes Design vs. Software Designbeschreibung</span>
    

- CDR: Critical Design Review
    <span style="color:gray">Informierung von Kunde bei kritischen Entscheidungen</span>
    

- IPR: In Process Review

Ohne Kunde

- MR: Management Review
- Code Walkthrough
- Technical Review
- Inspektion

![image.png](@media/6BIJzens.png)