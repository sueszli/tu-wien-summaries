Crowdsourcing in SE: Definition
---
“The act of undertaking any external software engineering tasks by an undefined, potentially large group of online workers in an open call format.”