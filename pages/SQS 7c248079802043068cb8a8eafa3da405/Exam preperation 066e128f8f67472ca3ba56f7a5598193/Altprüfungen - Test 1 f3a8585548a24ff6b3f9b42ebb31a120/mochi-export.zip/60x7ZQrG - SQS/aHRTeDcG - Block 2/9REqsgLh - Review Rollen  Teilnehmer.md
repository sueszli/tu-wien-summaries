Review: Rollen / Teilnehmer
---
<table>
  <tr>
    <th>Moderator</th>
    <th>Leiter des Reviews <span style="color:gray">(keeper of the process)</span></th>
  </tr>
  <tr>
    <th>Leser</th>
    <th>Leser <span style="color:gray">(keeper of focus and pace)</span></th>
  </tr>
  <tr>
    <th>Gutachter</th>
    <th>Kommentierung des Prüfobjekts <span style="color:gray">(Reviewer)</span></th>
  </tr>
  <tr>
    <th>Schreiber</th>
    <th>Verfassung von Protokoll <span style="color:gray">(preserver of knowledge)</span></th>
  </tr>
  <tr>
    <th>Autor</th>
    <th>Klärung von offenen Fragen - keine Rechtfertigung <span style="color:gray">(author)</span></th>
  </tr>
</table>
---
Anwesenheit basierend auf Produkt:
![image.png](@media/n7XG1YQV.png)