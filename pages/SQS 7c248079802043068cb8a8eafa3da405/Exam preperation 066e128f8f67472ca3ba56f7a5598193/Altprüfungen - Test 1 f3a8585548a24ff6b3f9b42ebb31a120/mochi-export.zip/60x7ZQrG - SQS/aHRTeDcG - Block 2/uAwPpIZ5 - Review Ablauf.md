Review: Ablauf

---

Vorgang nach Arbeitsplan / Checkliste

Nachträgliche Beurteilung des Reviews selbst zur Verbesserung

Dauer: ~2h


1. Planung    
  Teilnehmer, Prüfobjekt, Prüfziele, Auslösekriterien (Einstiegskriterien), Ort, Zeit, ... auswählen
    

2. Vorbesprechung (optional)  
    Vorstellung Prüfobjekt (falls Produkt komplex oder neu)
    

3. Einzeldurcharbeitung
    Teilnehmer bereiten sich vor - Beurteilen Prüfobjekt nach ihrer Rolle, notieren Auffälligkeiten (Fehler, Fragen, Kommentare)
    

4. Durchführung (Review Sitzung)
    Gemeinsames Lesen, Aufzeichnung von Mängel.
    Erkentnisse besprechen, protokollieren (Mängel nicht beheben).


5. Nachbearbeitung (Rework)
    dokumentierte Mängel beheben, Dokumente aktualisieren.
    

6. Bewertung (Follow-up)
    dokumentierte Mängel überprüft
    

7. Berichterstattung
    Wiederholungen von Reviews sind möglich

---

![image.png](@media/XFWhkzbq.png)