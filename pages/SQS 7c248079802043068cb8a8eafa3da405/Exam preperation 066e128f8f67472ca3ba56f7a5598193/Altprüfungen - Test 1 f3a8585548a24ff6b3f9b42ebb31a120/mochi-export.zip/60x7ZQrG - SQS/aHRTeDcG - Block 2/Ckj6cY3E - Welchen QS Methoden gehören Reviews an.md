Welchen QS Methoden gehören Reviews an?
---
Review, Inpektion, Audit sind *analytische, statische QS Methoden*.

Sie werden vor allem in frühen Phasen für Dokumente oder Code (muss nicht ausführbar sein) eingesetzt.