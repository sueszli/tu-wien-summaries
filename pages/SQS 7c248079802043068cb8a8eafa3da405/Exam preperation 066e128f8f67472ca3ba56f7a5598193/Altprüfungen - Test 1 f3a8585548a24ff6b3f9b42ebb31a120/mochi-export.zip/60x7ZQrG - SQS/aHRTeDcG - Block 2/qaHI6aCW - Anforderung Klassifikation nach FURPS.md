Anforderung: Klassifikation nach FURPS
---
- Functionality (Funktional)
    Features, Fähigkeiten, Sicherheitsvorrichtungen
    

- Usability (Benutzerfreundlich)
    Human factors, Nützlichkeit, Dokumentation

    
- Reliability (Zuverlässig)
    Uptime, Verlässlichkeit, Wiederherstellbarkeit

    
- Performance
    Antwortzeiten, Durchsatz, Genauigkeit

    
- Supportability (Wartbarkeit)
    Modifizierbarkeit, Wartung, Konfiguration

    

---

- Zur Laufzeit messbar: Performanz, Sicherheit, Verfügbarkeit, Verwendbarkeit
- Nicht zur Laufzeit messbar: Modifizierbarkeit, Portabilität, Wiederverwendbarkeit