Inspektion: Dimensionen
---
- Prozess
    1. Planung
    2. Überblick
    3. Fehlerfindung
    4. Fehlersammlung
    5. Fehlerkorrektur
    6. Follow-Up

    
- Produkt
    Anforderung, Design, Code, Testfälle

    
- Rollen
    Organisator, Moderator, Inspektor, Autor, Schreiber, Präsentator, Sammler

    
- Lesetechniken
    Ad-hoc, Checklisten-basiert, Szenario-basiert, Perspektiven-basiert, Fehler-basiert