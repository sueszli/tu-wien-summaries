Review vs. Debugging
---
Testen beschäftigt sich nicht mit der Lokalisierung von Fehlerstellen und dessen Entfernung (vgl. Debugging)

<span style="color:gray">*Siehe Block 1: Statische vs. dynamische Prüfungen*</span>