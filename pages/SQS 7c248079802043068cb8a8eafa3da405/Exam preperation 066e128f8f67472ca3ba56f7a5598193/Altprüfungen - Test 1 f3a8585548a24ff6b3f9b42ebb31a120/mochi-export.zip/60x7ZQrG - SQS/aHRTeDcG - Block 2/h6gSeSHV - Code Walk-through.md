Code Walk-through
---
Autor stellt seine Module ablauforientiert vor, Qualität der Implementierung wird begutachtet.

Neue Mitarbeiter können dabei zusehen, sich mit Projekt vertraut machen.

Autor selbst entscheidet ob etwas und was überarbeitet wird.

---

<table>
  <tr>
    <td>Ziel</td>
    <td>Fehler im Prüfobjekt finden, Benutzer und Mitarbeiter ausbilden</td>
  </tr>
  <tr>
    <td>Teilnehmer</td>
    <td>Autor (= Moderator), Gutachter</td>
  </tr>
  <tr>
    <td>Eigenschaften</td>
    <td>Prüfobjekt wird nach Ablauf von Autor vorgetragen und dieser entscheidet</td>
  </tr>
</table>