Technisches Review
---
Etwas formaleres Review: Moderator und Protokollführer anwesend.

Produkt wird begutachtet um Schwächen, Stärken zu finden.

Review-Team gibt Empfehlung an Management, das letztendlich entscheidet.


---

<table>
  <tr>
    <td>Ziel</td>
    <td>Stärken, Schwächen von Prüfobjekt finden, Prozess verbessern</td>
  </tr>
  <tr>
    <td>Teilnehmer</td>
    <td>Moderator, Autor, Gutachter, Protokollführer (kein Leser)</td>
  </tr>
  <tr>
    <td>Eigenschaften</td>
    <td>Alle Reviewer ausgebildet, Prüfteam gibt Empfehlung an Manager</td>
  </tr>
</table>