Inspektion: Allgemeines, Nutzen
---
in frühen Phasen der Fehlerfindeung

(zB auch für Anforderungsdokument, Designdokument, Testfälle, Code)

systematisch, formal, wirtschaftlich um Fehler zu finden

---

Einsparungen durch frühes Finden von Fehlern.

Beurteilungsgrundlage für Qualität (zB durch Restfehlerschätzungen).

Unterstützt von Lesetechniken und Fehlerlisten (Fehler in Teammeetings gesammelt)

Mehr Informationen über Produkt: Lerninstrument für neue Teammitglieder, Erkenntnisse für Management (PM und QM).