Inspektion: Kosten vs. Nutzen
---
Kosten

- Aufwand von Inspektoren, Einplanung im Projektplan

Nutzen

- Einsparungen durch frühe Fehlerfindung
- Beurteilungsgrundlage für Produktqualität (zB Restfehlerschätzungen)
- Mehr Informationen über Produkt zur Planung
- Inspektion als Lerninstrument für Inspektoren und neue Teammitglieder um Produkt kennenzulernen