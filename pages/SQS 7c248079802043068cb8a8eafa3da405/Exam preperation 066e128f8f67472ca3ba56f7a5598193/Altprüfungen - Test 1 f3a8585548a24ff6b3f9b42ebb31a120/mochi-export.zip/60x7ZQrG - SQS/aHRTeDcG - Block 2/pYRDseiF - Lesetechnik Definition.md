Lesetechnik: Definition
---
“strukturierte Ansätze oder Dokumente, die den Fehlerfindungsprozess während einer Inspektion oder einer Review unterstützen.”