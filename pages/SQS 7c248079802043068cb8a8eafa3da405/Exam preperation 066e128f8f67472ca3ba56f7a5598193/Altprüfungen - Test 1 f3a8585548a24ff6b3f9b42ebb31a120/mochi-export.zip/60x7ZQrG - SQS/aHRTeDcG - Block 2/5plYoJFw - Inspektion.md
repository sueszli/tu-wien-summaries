Inspektion
---
Formales Review - speziell in frühen Phasen der Entwicklung (zB für Anforderungs und Designdokumente).

Leser trägt Absatz für Absatz vor und Team versucht schwere Fehler zu finden.

Moderator entscheidet Freigabe.
---

<table>
  <tr>
    <td>Ziel</td>
    <td>Schwere Fehler im Prüfobjekt finden, Prozess verbessern, 
Metriken ermitteln</td>
  </tr>
  <tr>
    <td>Teilnehmer</td>
    <td>Moderator, Autor, Gutachter, Protokollführer, Vorleser</td>
  </tr>
  <tr>
    <td>Eigenschaften</td>
    <td>Ausgebildeter Moderator gibt Freigabe, Vorleser liest absatzweise vor</td>
  </tr>
</table>