Anwendungsfall Aufbau
---
Allgemein

1. Titel
2. Kurzbeschreibung
3. Beteiligte Akteure
4. Vorbedingung
5. Nachbedingung

Flow of events

1. Hauptszenario
2. Alternativszenario
3. Fehlerszenario

Nichtfunktionale Anforderungen