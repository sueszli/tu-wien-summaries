UML Sichten auf Software Strukturen - Charakteristika des Systems
---
1. *Konzeptionelle Sicht*
    Übersicht über Problembereich, Domäne — zB Domänenmodell
    

2. *Spezifizierende Sicht*
    Softwareschnittstellen, keine Implementierung — zB Komponentendiagramm
    

3. *Implementierende Sicht*
    Klassen als Grundlage für Implementierung — zB Klassendiagramm  
    (am häufigsten eingenommene Sicht)