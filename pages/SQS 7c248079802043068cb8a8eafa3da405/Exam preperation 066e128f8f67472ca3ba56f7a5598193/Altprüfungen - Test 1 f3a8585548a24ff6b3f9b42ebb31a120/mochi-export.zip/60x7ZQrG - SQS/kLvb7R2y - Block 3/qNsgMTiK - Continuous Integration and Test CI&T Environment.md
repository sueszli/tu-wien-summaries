Continuous Integration and Test (CI&T Environment)
---
= ein System, das bei Änderungen (neue Version im Versionsverwaltungssystem) automatisch die zusammenhängenden Tools (CI Pipeline) nutzt um eine Routine automatisch durchzuführen:

- testen, Metriken berechnen (zB Testabdeckung)
- builden
- zusammenführen (integrating)
- Testbericht erstellen im Dashboard und an Teammitglieder schicken

In maven ohne pipeline zB mit ”Cruise Control“, ”Apache Continuum“ und Bug-Tracking tools.

![image.png](@media/t1nfQqpl.png)