Testen vs. Debugging
---
- Testing
    
    Wird von einem Tester durchgeführt, um ein System bzw. eine Komponente auf Fehler zu prüfen. Entscheidend ist hier nur das Finden von Fehlern, nicht deren genaue Ursache.
    

- Debugging
    
    Wird vom Entwickler durchgeführt, um die Quelle eines Fehlers zu lokalisieren und den Fehler zu entfernen.