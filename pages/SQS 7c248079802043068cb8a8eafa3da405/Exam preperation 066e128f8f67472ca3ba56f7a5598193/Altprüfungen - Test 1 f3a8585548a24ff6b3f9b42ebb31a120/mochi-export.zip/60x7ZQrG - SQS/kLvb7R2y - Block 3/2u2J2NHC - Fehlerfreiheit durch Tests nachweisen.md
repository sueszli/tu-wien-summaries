Fehlerfreiheit durch Tests nachweisen
---
Kann man nicht - das wäre ein formaler Korrektheitsbeweis.