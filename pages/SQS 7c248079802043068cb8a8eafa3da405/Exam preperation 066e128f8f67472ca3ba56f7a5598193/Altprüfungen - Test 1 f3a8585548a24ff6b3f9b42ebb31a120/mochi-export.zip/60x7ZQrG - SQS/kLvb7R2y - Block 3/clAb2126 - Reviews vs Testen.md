Reviews vs. Testen
---
- Review
    zB. in frühen Phasen der Entwicklung Fehler erkennen. Muss nicht ausführbar sein (statische QS-Maßnahme).
    

- Testen
    Muss ausführbar sein (dynamische QS-Maßnahme).