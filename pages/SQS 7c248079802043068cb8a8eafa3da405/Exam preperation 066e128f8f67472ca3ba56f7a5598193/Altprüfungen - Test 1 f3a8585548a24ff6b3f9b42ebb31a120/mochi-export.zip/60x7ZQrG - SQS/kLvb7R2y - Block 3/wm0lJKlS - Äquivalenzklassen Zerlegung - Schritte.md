Äquivalenzklassen Zerlegung - Schritte
---
1. Zu testende Funktion bestimmen
2. Eingabe-Vektoren (Faktoren) finden (A, B, C, ...):
    - explizit: Parameter
    - implizit: globale Variablen, Systemzustand, Datenbankzustand, ...
    
3. Für jeden Faktor seine gültigen, ungültigen Äquivalenzklassen finden und aus jeder Klasse einen Wert wählen
    - A → A1, A2, ...
    - B → B1, B2, ...
    
4. Eine Kombination wählen
    die Wahl bestimmt die Intensität