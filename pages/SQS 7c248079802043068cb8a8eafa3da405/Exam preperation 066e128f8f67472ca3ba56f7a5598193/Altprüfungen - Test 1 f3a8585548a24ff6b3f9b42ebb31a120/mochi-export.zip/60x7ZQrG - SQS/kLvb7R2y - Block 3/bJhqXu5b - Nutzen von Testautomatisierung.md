Nutzen von Testautomatisierung
---
- repetitive manuelle Tätigkeiten reduzieren
- Die Effizienz des Testens zu steigern: Hohe Anzahl an Tests in angemessener Zeit ausführen
- Tests durchführen, die man nicht manuell durchführen kann (z.B. Last-Tests)
- Automatisch Reports der Testergebnisse generieren