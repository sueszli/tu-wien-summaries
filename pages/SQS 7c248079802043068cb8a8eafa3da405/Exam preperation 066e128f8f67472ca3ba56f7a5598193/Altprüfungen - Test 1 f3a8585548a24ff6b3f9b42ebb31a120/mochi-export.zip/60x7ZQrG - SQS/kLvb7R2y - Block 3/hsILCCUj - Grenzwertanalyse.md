Grenzwertanalyse
---
Erweiterung der Äquivalenzklassenzerlegung für bessere *Überdeckung*

Grenzwerte für jede Klassengrenze und dazu je ein Testfall

Ist eine Vertiefung der Äquivalenzklassenzerlegung, bei der gezielt die Ränder (= Grenzwerte) von den einzelnen Klassen überprüft werden, da dort am häufigsten Fehler (zB falscher Vergleichsoperator, Index one-off Fehler) auftreten.
---

![image.png](@media/vbzeiQWs.png)