Testfall
---
Testfall bestehen aus einer Menge (V, E, A, R)

- **V:** Vorbedingungen (zB Systemzustand, DB-Zustand)
- **E:** Eingabewerte
- **A:** Aktionen zur Eingabe der Werte
- **R:** Erwartete Ergebnisse (Orakel)