Verifikation vs. Validierung
---
**Verifikation**

- Test gegen Spezifikation (Pflichtenheft, ...)

- Nach jeder Phase durchführen

- _“Bauen wir das Produkt richtig?”_


**Validierung**

- Test gegen Nutzeranforderungen

- Zu Beginn: Validierung des Pflichtenhefts, der Spezifikation

- Am Ende: Validierung der erstellten Software

- _“Bauen wir das richtige Produkt?”_
---

![image.png](@media/URmZcaRi.png)