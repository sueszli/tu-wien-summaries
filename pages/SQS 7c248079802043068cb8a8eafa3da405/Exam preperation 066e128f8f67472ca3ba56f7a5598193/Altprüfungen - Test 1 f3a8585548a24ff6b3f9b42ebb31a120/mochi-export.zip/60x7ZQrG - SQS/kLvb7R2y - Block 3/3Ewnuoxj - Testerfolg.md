Testerfolg
---
Wenn Fehler gefunden wird

Tests die keine Fehler aufdecken bieten Information über *Produktqualität* durch *systematische Testüberdeckung*