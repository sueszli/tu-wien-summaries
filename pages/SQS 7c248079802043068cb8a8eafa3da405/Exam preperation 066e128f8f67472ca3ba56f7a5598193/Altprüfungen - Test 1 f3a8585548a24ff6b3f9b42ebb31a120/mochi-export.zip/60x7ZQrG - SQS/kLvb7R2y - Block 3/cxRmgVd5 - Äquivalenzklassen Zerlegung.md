Äquivalenzklassen Zerlegung
---
Zerlegung von Datenmenge (Input oder Output) in Untermengen (Klassen) basierend auf erwartetes Verhalten

- Klassen müssen äquivalente Ergebnisse und Wirkungen produzieren
- Dadurch sinkt Testaufwand

Jede Klasse muss 1x getestet werden