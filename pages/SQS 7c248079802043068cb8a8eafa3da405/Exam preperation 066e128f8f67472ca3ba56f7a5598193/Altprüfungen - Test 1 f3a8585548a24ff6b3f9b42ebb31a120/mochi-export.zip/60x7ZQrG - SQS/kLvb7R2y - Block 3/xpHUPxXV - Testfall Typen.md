Testfall Typen
---
- NF 	Normalfall $\rarr$ soll bei korrekter Implementierung funktionieren
- SF 	Spezialfall $\rarr$ Grenze zwischen Normalfall und Fehlerfall
- FF 	Fehlerfall $\rarr$ bei korrekter Implementierung Fehlermeldung werfen


Auswahl von Testfällen:
- Minimale Anzahl
- Qualität
- Risiko der Systemfunktionalität
---
![image.png](@media/7btpAWMM.png)