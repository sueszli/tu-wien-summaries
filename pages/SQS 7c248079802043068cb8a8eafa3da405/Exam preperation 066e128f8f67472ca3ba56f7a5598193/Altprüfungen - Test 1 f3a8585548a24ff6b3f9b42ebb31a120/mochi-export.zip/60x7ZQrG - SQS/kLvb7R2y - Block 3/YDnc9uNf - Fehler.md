Fehler
---
Abweichung von Spezifikation

Abweichung von Nutzer-Anforderungen