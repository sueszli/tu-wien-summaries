Wert von Fehlern / Testfällen: Value based Testing
---
<span style="color:gray">Value-Based-Testing beruht darauf dass nicht alle Testfälle bzw. alle Fehler gleich viel Wert sind.</span>

- Requirements-Based
  Welche Anforderungen bringen den meisten Mehwert für Kunden?

- Risk-Based
  Welche Risiken gefährden den Nutzen am meisten? (zB dependencies)

*Test Case Selection* = Testfälle finden die all diese Risiken und Nutzen abdecken