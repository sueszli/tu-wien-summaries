Testprozess Phasen
---
Ist eingebettet in Projektplan

1. Planung, Steuerung
  <span style="color:gray">Vorbereitung von “Test-Masterplan”: von Teststufen, Testmethoden</span>

2. Analyse, Design
  <span style="color:gray">von Spezifikation</span>

3. Realisierung, Durchführung
  <span style="color:gray">von Testläufen</span>

4. Auswertung, Bericht
  <span style="color:gray">Testergebnisse</span>

5. Abschluss
  <span style="color:gray">zB Archivierung</span>
---

![image.png](@media/VsGlxmRV.png)