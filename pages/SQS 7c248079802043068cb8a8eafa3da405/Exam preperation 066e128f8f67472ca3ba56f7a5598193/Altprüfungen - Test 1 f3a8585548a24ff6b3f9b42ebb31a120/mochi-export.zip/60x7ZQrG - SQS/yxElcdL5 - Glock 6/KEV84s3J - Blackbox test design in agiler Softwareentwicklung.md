Blackbox test design in agiler Softwareentwicklung
---
In agilen Projekten Tests gleichzeitig mit Komponenten entwickelt (nach US, Abnahmekriterien)

*Blackbox Testentwurfsverfahren: Äquivalenzklassenbildung, Grenzwertanalyse (um Testwerte auszuwählen), Entscheidungstabellen, zustandsbasierte Tests.*