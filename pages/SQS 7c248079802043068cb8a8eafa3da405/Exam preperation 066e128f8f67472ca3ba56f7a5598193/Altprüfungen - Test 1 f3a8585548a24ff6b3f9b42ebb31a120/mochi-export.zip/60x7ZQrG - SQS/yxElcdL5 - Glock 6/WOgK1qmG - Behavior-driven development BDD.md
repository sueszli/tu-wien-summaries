Behavior-driven development (BDD)
---
Entwickler testet *erwartetes Verhalten*

Stakeholder können Funktionalität durch Tests nachvollziehen (Abnahmekriterien).

<p style="margin-top:2rem">

In manchen Frameworks Gherkin-Format (deklarativ) → automatische Testerstellung:

*Gegeben ein Einstiegskontext,
Wenn ein Ereignis auftritt,
Dann werden bestimmte Wirkungen sichergestellt*