Testen von Akzeptanzkriterien (Beispiel)
---
Beispiel: Registrieren Funktion

1. Conditions of Satisfaction
    <span style="color:gray">Welche Bedingungen, Anforderungen gibt es? “Passwörter dürfen nicht knackbar sein”</span>
    

2. Acceptance Criteria
    <span style="color:gray">Wann gilt ein Passwort als “nicht knackbar”?</span>
    
    - <span style="color:gray">Mind. 8 Zeichen, aber nicht mehr als 12</span>
    - <span style="color:gray">Darf nur alphanumerische Zeichen beinhalten</span>
    - <span style="color:gray">Muss mind. eine Zahl beinhalten</span>
    - <span style="color:gray">Muss mind. einen Buchstaben beinhalten</span>

    
3. (Executable) Examples
    <span style="color:gray">Erstellung von Testdaten: “abc123”, “abcdefghi”, “1aaaaaaaaa”, “ajx972dab”</span>
    
    <span style="color:gray">zB durch BDD:</span>
    
    ```
    Given the "Unregistered User" user has navigated to the "register" page
    
    When entering "newuser" in the "Username" field
    And entering "abc123" in the "Password" field
    And entering "abc1 23" in the "Confirm Password" field
    And pressing the "Register" button
    
    Then the text "Thank you for Registering" should appear on page
    And the URL should end with "use/accountPage"
    ```