Continous Integration CI
---
Nach jeder Iteration muss funktionierende Software vorliegen.

Kontinuierlich (min 1x am Tag oder bei Änderungen) automatisiert in CI-Pipeline durchgeführt:

*Komponenten miteinander zusammenführen (Integration)*
- Konfigurationsmanagement
- Kompilierung, Build
- Verteilung in Production Environment
- Ausführung in Testumgebung (Berechnung von Metriken zB Test converage)

Aktivitäten:
- Statische Codeanalyse
- Kompilieren und Linken, executable herstellen
- Unittests, Code Coverage
- Deployment (Bereitstellung), Installieren der Software in einer Testumgebung
- Integrationstests, Systemtests in Testumgebung
- Dashboard
---

![image.png](@media/l8iqFQNN.png)

![image.png](@media/nkJPFKGI.png)