Eigene Tester vs. keine eigenen Tester in Scrum
---
Keine Tester im Scrum Prozess
- Testen ist Teil der Entwicklung (Unit Tests, TDD)
- Akzetanztests durch Owner, Kunde nach jedem Sprint


Vorteil von eigenen Testern
- Fokus auf Kundensicht statt technische implementierung
- Fokus auf Fehler anstatt von Überprüfung der Vollständigkeit