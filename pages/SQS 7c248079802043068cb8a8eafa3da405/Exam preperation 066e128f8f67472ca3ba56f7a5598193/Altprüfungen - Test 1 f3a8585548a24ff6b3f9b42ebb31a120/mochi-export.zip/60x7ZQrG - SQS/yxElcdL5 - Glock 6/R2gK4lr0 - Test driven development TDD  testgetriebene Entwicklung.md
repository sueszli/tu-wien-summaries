Test driven development TDD / testgetriebene Entwicklung
---
eher Unit-Tests, automatisiert in CI

1. Think
  - Auswahl der Anforderungen die implementiert werden sollen
  - Testfall-Spezifikation

    
2. Red
  Implementierung und Ausführung der Testfälle.
  Alle Tests müssen fehlschlagen.

    
3. Green
    Implementierung der Komponenten und Klassen und Ausführung der Testfälle
  - erfolgreich → weiter bei Schritt 4, Refactor
  - schlägt fehlt →  weiter bei Schritt 3, Green
    

4. Refactor
    Optimierung der Implementierung ohne Änderung der Funktionalität, Ausführung der Testfälle.
  - Testfälle dürfen nicht fehlschlagen.
  - Auswahl der nächsten Anforderung (weiter zu Schritt 1)
---
![image.png](@media/JbaGDZYp.png)