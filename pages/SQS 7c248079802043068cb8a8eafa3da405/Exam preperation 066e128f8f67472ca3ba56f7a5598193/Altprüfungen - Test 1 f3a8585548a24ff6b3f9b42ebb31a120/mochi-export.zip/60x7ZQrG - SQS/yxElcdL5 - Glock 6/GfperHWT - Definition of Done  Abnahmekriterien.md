Definition of Done / Abnahmekriterien
---
Kriterien anhand denen entschieden wird, ob Inkrement abgeschlossen
---
Abnahmekriterien mit Abnahmetests getestet:

- Funktionales Verhalten
- Qualitätsmerkmale
- Szenarios (Use Cases)
- Geschäftsprozessregeln
- Externe Schnittstellen
- Einschränkungen
- Datendefinitionen


*Abnahmekriterien für Userstories*
- Ausgewählte US für Iteration sind reviewed, vollständig, verständlich und haben detaillierte, testbare Abnahmekriterien.
- Abnahmetests als Testbeschreibung, Testscript bereitgestellt.
- Aufgaben für die Implementierung, Testen identifiziert und Aufwand eingeschätzt.

*Letzte Iteration*
- Alle Features der Iteration fertig entwickelt, nach Feature-Level Kriterien getestet.
- Nicht-kritischen Fehler, die nicht behoben wurden im Product Backlog und priorisiert.
- Integration aller Feature erfolgt, getestet.
- Dokumentation nach Review abgenommen.
---
![image.png](@media/Bbx88XyW.png)