User stories
---
Anforderungen aus der Sicht eines Fachbereichsvertreter (Funktionale und Nicht-Funktionale Eigenschaften) und Abnahmekriterien

Befinden sich im Product-Backlog

Spezifikation

---

Konstrukt: As a *[user role]*, I want to *[goal]*, so that I can *[reason]*.