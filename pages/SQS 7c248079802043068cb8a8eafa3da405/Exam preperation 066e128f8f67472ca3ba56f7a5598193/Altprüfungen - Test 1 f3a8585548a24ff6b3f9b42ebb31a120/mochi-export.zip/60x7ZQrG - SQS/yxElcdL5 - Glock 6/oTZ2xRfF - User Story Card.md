User Story Card
---
1. Card
    Das physische Medium, dass die Userstory beschreibt.
    Beinhaltet genaue Anforderung, Dringlichkeit, erwartete Testdauer, erwartete Entwicklungsdauer, Abnahmekriterien.


2. Conversation    
    Diskussion die erklärt wie Software genutzt werden soll.


3. Confirmation
    Definition of done $\rarr$ Abnahmekriterien die in Diskussion festgelegt werden.
    Bestätigung des Abschlusses der Userstory.

---

Beispiel:
![image.png](@media/lxxGjuex.png)

Confirmation

1. Success-valid user logged in and referred to home page.
a. “Remember me” ticked - store cookie/ automatic login next timne.
b. “Remember me” not ticked -force login next time.
2. Failure- display message:
a) "Email address in wrong format"
b) "Unrecognised user name, please try again"
c) Incorrect password, please try again"
d) "Service unavailable, please try again"
e) Account has expired- refer to account renewal sales page.