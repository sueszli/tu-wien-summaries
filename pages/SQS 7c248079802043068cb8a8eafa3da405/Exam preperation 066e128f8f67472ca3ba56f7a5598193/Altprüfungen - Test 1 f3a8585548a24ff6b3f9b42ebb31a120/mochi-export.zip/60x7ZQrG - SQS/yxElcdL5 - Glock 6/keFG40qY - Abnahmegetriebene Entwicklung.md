Abnahmegetriebene Entwicklung
---
US enthält Abnahmekriterien, Test

Stakeholder können Funktionalität durch Tests nachvollziehen (Abnahmekriterien).

Wiederverwendbare Tests für Regressionserstellung.