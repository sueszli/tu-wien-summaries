Exploratives testen
---
Wichtig wegen begrenzter Zeit für Testanalyse und Detailgenauigkeit der US.

zusätzlich zu anderen Testentwurfsverfahren

basiert auf Intuition, Erfahrung des Testers

zB Erfahrung aus anderen Projekten, Stellen die unter Zeitdruck entstanden sind etc.

muss dokumentiert werden

---

Vorgehen: Erfahrungsbasiertes Verfahren
- Riskobasiertes Testen
- Anforderungsbasiertes Testen
- Modellbasiertes Testen
- Regessionsvermeidendes Testen

---

Testsitzungen beinhalten:

- Überblickssitzung $\rarr$ um zu lernen, wie es funktioniert
- Analysesitzung $\rarr$ Bewertung von Funktionalität, Eigenschaften
- Genaue Überdeckung $\rarr$ Ausnahmefälle, Szenarien, Interaktionen