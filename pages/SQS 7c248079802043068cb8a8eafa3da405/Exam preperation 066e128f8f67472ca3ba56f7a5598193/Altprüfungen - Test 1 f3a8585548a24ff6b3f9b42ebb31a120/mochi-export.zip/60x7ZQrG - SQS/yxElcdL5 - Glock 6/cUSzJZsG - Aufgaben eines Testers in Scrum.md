Aufgaben eines Testers in Scrum
---

Planen, Verwalten
- Test Ansatz, Planung
- Verwaltung von Testfällen im Source Code Manager SCM


Risiken und Tracability einschätzen
- Risikoanalyse, Risikoabschätzung
- Schätzung, Tracability von Tests der User Stories

Testen, Automatisieren
- Statisches Testen (Anforderungen, Dokumentation)
- Dynamisches Testen (Ausführung von Akzeptanztests)
- Erstellung von Akzeptanztests
- Regressionstests (manuell & automatisiert)
- Erstellung und Wartung von automatisierten Tests


Unterstützen
- Unterstützung bei Unit Tests und TTD
- Unterstützung bei Akzeptanztests


Demonstrieren
- Demonstration während des Sprint Reviews